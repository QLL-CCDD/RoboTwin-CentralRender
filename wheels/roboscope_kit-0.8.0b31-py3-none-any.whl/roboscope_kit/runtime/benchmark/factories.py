# Copyright 2026 RoboScope Team
# SPDX-License-Identifier: Apache-2.0

"""Factory contracts for constructing benchmark adapters."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from roboscope_kit.benchmark_specs import BenchmarkName

from .adapters import BenchmarkAdapter
from .manifest import BenchmarkManifest


@dataclass(frozen=True)
class BenchmarkRunRequest:
    benchmark: BenchmarkName
    suite: str
    checkpoint_path: Path
    output_dir: Path
    episodes: int | None
    quick_test: bool
    evaluation_config_path: Path | None = None


class BenchmarkFactory(Protocol):
    def validate_suite(self, suite: str) -> None: ...

    def create(
        self,
        request: BenchmarkRunRequest,
        manifest: BenchmarkManifest,
    ) -> BenchmarkAdapter: ...

    def create_probe(
        self,
        request: BenchmarkRunRequest,
        manifest: BenchmarkManifest,
        concurrency: int,
    ) -> BenchmarkAdapter: ...

    def self_test(self, manifest: BenchmarkManifest, output_dir: Path) -> dict: ...


def representative_indices(total: int, count: int) -> tuple[int, ...]:
    """Select deterministic indices spanning a benchmark workload."""

    if total < 1 or count < 1:
        raise ValueError("probe workload size must be positive")
    selected_count = min(total, count)
    return tuple(index * total // selected_count for index in range(selected_count))


def nested_task_order(total: int) -> tuple[int, ...]:
    """Task indices whose every prefix spans the workload and contains each shorter prefix.

    A probe that needs more tasks takes a longer prefix, so it repeats every
    episode of a smaller probe and the correctness check compares the same episodes.
    """

    order: dict[int, None] = {}
    for count in range(1, total + 1):
        order.update(dict.fromkeys(representative_indices(total, count)))
    return tuple(order)


def nested_task_prefix(total: int, count: int) -> tuple[int, ...]:
    """The first ``count`` indices of :func:`nested_task_order`, in ascending order.

    Builds only as much of the order as the prefix needs, so a probe over a large
    task catalog does not pay for the whole order.
    """

    if total < 1 or count < 1:
        raise ValueError("probe workload size must be positive")
    wanted = min(total, count)
    order: dict[int, None] = {}
    size = 1
    while len(order) < wanted:
        order.update(dict.fromkeys(representative_indices(total, size)))
        size += 1
    return tuple(sorted(list(order)[:wanted]))


__all__ = [
    "BenchmarkFactory",
    "BenchmarkRunRequest",
    "nested_task_order",
    "nested_task_prefix",
    "representative_indices",
]
